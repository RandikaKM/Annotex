"""
Annotex -  Annotation Tool
"""

__version__ = "2.0.0"
__author__ = "Randika K. Makumbura"
__email__ = "Randikamk.96@gmail.com"

from annotex.main import main

__all__ = ["main", "__version__"]