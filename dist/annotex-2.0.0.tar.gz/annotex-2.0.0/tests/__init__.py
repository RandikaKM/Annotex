"""
Test suite for Annotex
"""